<template>
  <SpotrebaChart />
</template>

<script setup>
import SpotrebaChart from '../components/SpotrebaChart.vue'
</script>
